//
//  main.m
//  prj1
//
//  Created by user166370 on 3/18/20.
//  Copyright © 2020 user166370. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
const char* parse(const char* rcfile, char* dicdir, const char* input);

int main(int argc, char * argv[]) {
    NSString* st1 = [[NSBundle mainBundle] pathForResource:@"mecabrc" ofType: @""];
    
    const char* rcfile = [st1 UTF8String];

    NSString* st2 = [[NSBundle mainBundle] pathForResource:@"ipadic" ofType: @""];
    
    const char* dicdir = [st2 UTF8String];
    const char input[] = "にわにわにわにわとりがいる。";
    const char *result = parse(rcfile, dicdir, input);
    printf ("INPUT: %s\n", input);
    printf ("RESULT:\n%s", result);
    NSString * appDelegateClassName;
    
    @autoreleasepool {
        // Setup code that might create autoreleased objects goes here.
        appDelegateClassName = NSStringFromClass([AppDelegate class]);
    }
    return UIApplicationMain(argc, argv, nil, appDelegateClassName);
}
