//
//  ViewController.m
//  prj1
//
//  Created by user166370 on 3/18/20.
//  Copyright © 2020 user166370. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}


@end
