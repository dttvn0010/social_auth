//
//  AppDelegate.h
//  prj1
//
//  Created by user166370 on 3/18/20.
//  Copyright © 2020 user166370. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>


@end

