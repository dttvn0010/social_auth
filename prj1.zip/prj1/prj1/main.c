#include "mecab.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

char* fn = (char*) "";

#define CHECK(eval) if (! eval) { \
    fprintf (stderr, "Exception:%s\n", mecab_strerror (mecab)); \
    mecab_destroy(mecab);\
    return NULL;\
}

void test() {
    FILE* f = fopen("./prj1.app/mecabrc", "rt");
    char s[256];
    fgets(s,256,f);
    printf("%s\n",s);
}

const char* parse(const char* rcfile, const char* dicdir, const char* input) {
  mecab_t *mecab;
  
  // Create tagger object
    char s1[256], s2[256];
    sprintf(s1,"--rcfile=%s", rcfile);
    sprintf(s2,"--dicdir=%s", dicdir);
    char* argv[3] = {(char*)"mecab", s1, s2};
    mecab = mecab_new(3, argv);
    CHECK(mecab);

  // Gets tagged result in string.
  const char* result = mecab_sparse_tostr(mecab, input);
  const char* output = (const char*) malloc(1 + strlen(result));
  strcpy((char*)output, (char*)result);
  mecab_destroy(mecab);  
  return output;
}


